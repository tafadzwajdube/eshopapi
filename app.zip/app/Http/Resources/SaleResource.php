<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Carbon\Carbon;

class SaleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
     //   return parent::toArray($request);
     return[

        "id"=>$this->id,
        "created_by"=>$this->created_by,
        "date"=>$this->date,
        "location"=>$this->location,
        "products"=>$this->productsales,
        "total"=>$this->getTotal($this->productsales),
        "created_at"=>Carbon::parse($this->created_at)->format('d M Y'),
        "updated_at"=>$this->updated_at
     ];
    }

      function getTotal($products){

            $total=0;
            foreach($products as $p){

                $total=$total+$p->cost_rand;
            }

            return $total;
    }
}
